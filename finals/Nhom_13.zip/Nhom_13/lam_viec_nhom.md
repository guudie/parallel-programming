Làm việc nhóm
=============

**Thành viên:**
| Họ tên | MSSV |
| :--- | :--- |
| Nguyễn Tiến Toàn | 19120399 |
| Nguyễn Trung Dũng | 19120486 |

**Công việc:**
| Công việc | SV thực hiện | Ngày hoàn thành |
| :--- | :--- | :---: |
| Lên ý tưởng | Nguyễn Tiến Toàn</br> Nguyễn Trung Dũng | 25/12/2022 |
| Viết code cho host | Nguyễn Trung Dũng | 25/12/2022 |
| Viết code cho version 1 | Nguyễn Tiến Toàn</br> Nguyễn Trung Dũng | 25/12/2022 |
| Viết code cho version 2 | Nguyễn Tiến Toàn</br> Nguyễn Trung Dũng | 26/12/2022 |
| Viết code cho version 3 | Nguyễn Tiến Toàn</br> Nguyễn Trung Dũng | 28/12/2022 |
| Viết code cho version 4 và thử nghiệm | Nguyễn Trung Dũng | 2/1/2023 |
| Viết báo cáo, chạy & đo thời gian | Nguyễn Tiến Toàn | 6/1/2023 |